const CONFIG = {
  BOT_COMMANDS_PATH: '/bot-commands.html',
  HOME_PATH: '/index.html',
};
